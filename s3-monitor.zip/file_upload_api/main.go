package main

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"os"
	"strings"
	"time"

	"github.com/aws/aws-lambda-go/events"
	"github.com/aws/aws-lambda-go/lambda"
	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/dynamodb"
	"github.com/aws/aws-sdk-go/service/dynamodb/dynamodbattribute"
	"github.com/aws/aws-sdk-go/service/s3"
)

type UploadRequest struct {
	FileName string `json:"fileName"`
	FileType string `json:"fileType"`
	FileSize string `json:"fileSize"`
}

type UploadResponse struct {
	URL string `json:"url"`
}

type S3UploadLog struct {
	URI        string `json:"URI"`
	ObjectName string `json:"object_name"`
	ObjectSize string `json:"object_size"` // will be 0 initially
	ObjectType string `json:"object_type"`
	UploadDate string `json:"upload_date"`
}

var (
	bucket    = os.Getenv("BUCKET_NAME")
	tableName = os.Getenv("DYNAMODB_TABLE")
	sess      = session.Must(session.NewSession())
	s3Svc     = s3.New(sess)
	db        = dynamodb.New(sess)
	headers   = map[string]string{
		"Content-Type":                 "application/json",
		"Access-Control-Allow-Origin":  "*",                           // Allow requests from any origin
		"Access-Control-Allow-Methods": "OPTIONS,GET,POST,PUT,DELETE", // Allow specific HTTP methods
		"Access-Control-Allow-Headers": "Content-Type",                // Allow specific headers
	}
)

func handler(ctx context.Context, req events.APIGatewayProxyRequest) (events.APIGatewayProxyResponse, error) {
	switch req.HTTPMethod {
	case "POST":
		return handlupload(req)
	default:
		return events.APIGatewayProxyResponse{StatusCode: http.StatusMethodNotAllowed, Headers: headers}, nil
	}
}

func handlupload(req events.APIGatewayProxyRequest) (events.APIGatewayProxyResponse, error) {
	var uploadReq UploadRequest
	err := json.Unmarshal([]byte(req.Body), &uploadReq)
	if err != nil {
		return events.APIGatewayProxyResponse{StatusCode: http.StatusBadRequest, Body: "Invalid request", Headers: headers}, nil
	}

	cdatetime := time.Now().Format("2006-01-0215:04:05")
	key := fmt.Sprintf("uploads/%s", uploadReq.FileName+cdatetime)

	// Generate presigned URL
	reqParams := &s3.PutObjectInput{
		Bucket:      aws.String(bucket),
		Key:         aws.String(key),
		ContentType: aws.String(uploadReq.FileType),
	}
	reqPresign, _ := s3Svc.PutObjectRequest(reqParams)
	urlStr, err := reqPresign.Presign(15 * time.Minute)
	if err != nil {
		log.Println("Error", err.Error())
		return events.APIGatewayProxyResponse{StatusCode: http.StatusInternalServerError, Body: "Failed to generate URL" + err.Error(), Headers: headers}, nil
	}

	// Save initial log to DynamoDB
	ext := "unknown"
	parts := strings.Split(uploadReq.FileName, ".")
	if len(parts) > 1 {
		ext = parts[len(parts)-1]
	}

	logEntry := S3UploadLog{
		URI:        fmt.Sprintf("s3://%s/%s", bucket, key),
		ObjectName: key,
		ObjectSize: uploadReq.FileSize, // since not uploaded yet
		ObjectType: ext,
		UploadDate: time.Now().Format(time.RFC3339),
	}

	av, err := dynamodbattribute.MarshalMap(logEntry)
	if err != nil {
		return events.APIGatewayProxyResponse{StatusCode: http.StatusInternalServerError, Body: "Failed to log upload", Headers: headers}, nil
	}

	_, err = db.PutItem(&dynamodb.PutItemInput{
		TableName: aws.String(tableName),
		Item:      av,
	})
	if err != nil {
		return events.APIGatewayProxyResponse{StatusCode: http.StatusInternalServerError, Body: "Failed to save upload info" + err.Error(), Headers: headers}, nil
	}

	// Return URL to client
	resp := UploadResponse{URL: urlStr}
	body, _ := json.Marshal(resp)
	return events.APIGatewayProxyResponse{
		StatusCode: http.StatusOK,
		Body:       string(body),
		Headers:    headers,
	}, nil
}

func main() {
	lambda.Start(handler)
}
