// main.go - SendDailyS3Report
package main

import (
	"bytes"
	"context"
	"fmt"
	"log"
	"os"
	"strings"
	"time"

	"github.com/aws/aws-lambda-go/lambda"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/dynamodb"
	"github.com/aws/aws-sdk-go/service/dynamodb/dynamodbattribute"
	"github.com/aws/aws-sdk-go/service/ses"
)

type S3UploadLog struct {
	URI        string `json:"uri"`
	ObjectName string `json:"object_name"`
	ObjectSize string `json:"object_size"`
	ObjectType string `json:"object_type"`
	UploadDate string `json:"upload_date"`
}

var (
	tableName       = os.Getenv("DYNAMODB_TABLE")
	emailSender     = os.Getenv("EMAIL_SENDER")
	emailRecipients = strings.Split(os.Getenv("EMAIL_RECIPIENTS"), ",")
	sess            = session.Must(session.NewSession())
	db              = dynamodb.New(sess)
	sesSvc          = ses.New(sess)
)

func handler(ctx context.Context) error {
	// Scan all records (optionally filter manually)
	result, err := db.Scan(&dynamodb.ScanInput{TableName: &tableName})
	if err != nil {
		return err
	}

	var logs []S3UploadLog
	err = dynamodbattribute.UnmarshalListOfMaps(result.Items, &logs)
	if err != nil {
		return err
	}

	// Filter today's uploads
	today := time.Now().UTC().Format("2006-01-02")
	var buffer bytes.Buffer
	buffer.WriteString("Daily S3 Upload Report\n\n")

	for _, log := range logs {
		if strings.HasPrefix(log.UploadDate, today) {
			buffer.WriteString(fmt.Sprintf("S3 URI: %s\n", log.URI))
			buffer.WriteString(fmt.Sprintf("Object Name: %s\n", log.ObjectName))
			buffer.WriteString(fmt.Sprintf("Object Size: %d bytes\n", log.ObjectSize))
			buffer.WriteString(fmt.Sprintf("Object Type: %s\n", log.ObjectType))
			buffer.WriteString("-----\n")
		}
	}

	if buffer.Len() == 0 {
		buffer.WriteString("No uploads today.")
	}

	// Send email
	_, err = sesSvc.SendEmail(&ses.SendEmailInput{
		Source: &emailSender,
		Destination: &ses.Destination{
			ToAddresses: awsStrings([]string{"rajputarnav688@gmail.com", "2023MT13186@wilp.bits-pilani.ac.in", "2023mt13192@wilp.bits-pilani.ac.in", "2023MT13144@wilp.bits-pilani.ac.in"}),
		},
		Message: &ses.Message{
			Subject: &ses.Content{Data: awsString("Daily S3 Upload Report")},
			Body: &ses.Body{
				Text: &ses.Content{Data: awsString(buffer.String())},
			},
		},
	})
	log.Println("Email sent successfully", err)
	return err
}

func awsString(s string) *string {
	return &s
}

func awsStrings(ss []string) []*string {
	var result []*string
	for _, s := range ss {
		result = append(result, awsString(s))
	}
	return result
}

func main() {
	lambda.Start(handler)
}
